#pragma once

#include "htable.h"

unsigned int parse_n_store_words(char *buf, htable_t *ht);
