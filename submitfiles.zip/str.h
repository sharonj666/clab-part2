#pragma once

int string_len(char *s);
int string_cmp(char *s1, char *s2);
void int_to_hex(unsigned int x, char *src);
